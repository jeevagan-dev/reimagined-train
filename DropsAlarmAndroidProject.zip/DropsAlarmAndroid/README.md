# Drops Alarm Android project

Native Android app project (Java), daily alarm notifications, vibration, rescheduling after device reboot.

## Build APK
- Open this project in Android Studio (JDK 17; Android SDK 35), sync Gradle, then Build > Build APK(s).
- APK path: `app/build/outputs/apk/debug/app-debug.apk`

Or push the folder to a GitHub repository, then open Actions > Build Drops Alarm APK > Run workflow. Download the `DropsAlarm-debug-apk` artifact.

On Android 13+, grant notifications. On Android 12+, allow exact alarms if prompted/settings. OEM battery restrictions may still delay alarms. Follow doctor's dose instructions.
