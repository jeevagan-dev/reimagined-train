package com.codebruh.dropsalarm;
import android.app.*;import android.content.*;import android.media.*;import android.os.*;
public class AlarmReceiver extends BroadcastReceiver{
 public void onReceive(Context c,Intent i){String med=i.getStringExtra("med"),time=i.getStringExtra("time");int id=i.getIntExtra("id",0);String channel="drops_channel";NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(channel,"Eye drop reminders",NotificationManager.IMPORTANCE_HIGH));
  Intent open=new Intent(c,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,channel):new Notification.Builder(c);b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("💧 Drops reminder").setContentText("Time for "+med+" · "+time).setAutoCancel(true).setContentIntent(pi).setVibrate(new long[]{0,350,200,350});nm.notify(100+id,b.build());
  AlarmUtil.set(c,id,med,time);
 }
}
