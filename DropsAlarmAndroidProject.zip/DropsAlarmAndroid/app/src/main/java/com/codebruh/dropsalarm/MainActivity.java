package com.codebruh.dropsalarm;

import android.app.*;import android.content.*;import android.graphics.Color;import android.os.*;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
 EditText medicine, firstTime; Spinner count; TextView status, schedule; LinearLayout root;
 @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(7,59,54));getWindow().setNavigationBarColor(Color.rgb(7,59,54));
  if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=0)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},10);
  root=new LinearLayout(this);root.setOrientation(1);root.setPadding(32,28,32,24);root.setBackgroundColor(Color.rgb(242,248,247));ScrollView sc=new ScrollView(this);sc.addView(root);setContentView(sc);
  TextView title=new TextView(this);title.setText("💧  Drops Alarm");title.setTextSize(28);title.setTextColor(Color.rgb(7,59,54));title.setGravity(Gravity.CENTER);title.setPadding(0,20,0,24);root.addView(title);
  addLabel("Medicine name");medicine=new EditText(this);medicine.setSingleLine();medicine.setText("Eye drops");root.addView(medicine);
  addLabel("First dose time (HH:mm)");firstTime=new EditText(this);firstTime.setSingleLine();firstTime.setInputType( android.text.InputType.TYPE_CLASS_DATETIME|android.text.InputType.TYPE_DATETIME_VARIATION_TIME);firstTime.setText("08:00");root.addView(firstTime);
  addLabel("Reminders per day");count=new Spinner(this);String[] vals={"2","3","4","5","6","7","8"};count.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,vals));count.setSelection(4);root.addView(count);
  Button set=btn("Set daily reminders");root.addView(set);set.setOnClickListener(v->setAlarms());
  Button cancel=btn("Cancel all reminders");root.addView(cancel);cancel.setOnClickListener(v->{AlarmUtil.cancelAll(this);status.setText("All alarms cancelled.");});
  schedule=new TextView(this);schedule.setTextSize(16);schedule.setTextColor(Color.DKGRAY);schedule.setPadding(0,22,0,10);root.addView(schedule);
  status=new TextView(this);status.setTextSize(15);status.setTextColor(Color.rgb(7,100,80));status.setPadding(0,18,0,12);root.addView(status);
  TextView note=new TextView(this);note.setText("Follow your ophthalmologist's prescription exactly. This app only reminds you; it does not prescribe doses. Allow notifications and exact alarms in Android settings if prompted.");note.setTextColor(Color.GRAY);note.setPadding(0,20,0,0);root.addView(note);
 }
 void addLabel(String s){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.rgb(55,75,75));t.setPadding(0,12,0,4);root.addView(t);} Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(15,157,138)));b.setPadding(0,10,0,10);return b;}
 void setAlarms(){try{String med=medicine.getText().toString().trim();if(med.isEmpty())med="Eye drops";String[] p=firstTime.getText().toString().split(":");int h=Integer.parseInt(p[0]),m=Integer.parseInt(p[1]);if(h>23||m>59)throw new Exception();int n=Integer.parseInt(count.getSelectedItem().toString());AlarmUtil.cancelAll(this);StringBuilder sb=new StringBuilder("Scheduled daily:\n");for(int i=0;i<n;i++){int mins=(h*60+m)+(i*(16*60/Math.max(1,n-1)));int hh=(mins/60)%24,mm=mins%60;String time=String.format(Locale.US,"%02d:%02d",hh,mm);AlarmUtil.set(this,i,med,time);sb.append("• ").append(time).append("\n");}schedule.setText(sb.toString());status.setText("✓ Reminders scheduled. Keep notifications enabled.");}catch(Exception e){status.setText("Enter a valid time like 08:00.");}}
}
