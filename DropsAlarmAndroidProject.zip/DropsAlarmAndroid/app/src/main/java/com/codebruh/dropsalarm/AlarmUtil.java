package com.codebruh.dropsalarm;
import android.app.*;import android.content.*;import android.os.*;import java.util.*;
class AlarmUtil{
 static final String PREF="drops_alarm_prefs";
 static void set(Context c,int id,String med,String time){String[] a=time.split(":");Calendar cal=Calendar.getInstance();cal.set(Calendar.HOUR_OF_DAY,Integer.parseInt(a[0]));cal.set(Calendar.MINUTE,Integer.parseInt(a[1]));cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);if(cal.getTimeInMillis()<=System.currentTimeMillis())cal.add(Calendar.DAY_OF_YEAR,1);
  Intent in=new Intent(c,AlarmReceiver.class).putExtra("med",med).putExtra("time",time).putExtra("id",id);PendingIntent pi=PendingIntent.getBroadcast(c,id,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)c.getSystemService(ALARM_SERVICE);
  if(Build.VERSION.SDK_INT>=31&&am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi);else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi);
  c.getSharedPreferences(PREF,0).edit().putString("m"+id,med).putString("t"+id,time).putInt("n",Math.max(id+1,c.getSharedPreferences(PREF,0).getInt("n",0))).apply();}
 static void cancelAll(Context c){SharedPreferences p=c.getSharedPreferences(PREF,0);int n=p.getInt("n",8);AlarmManager am=(AlarmManager)c.getSystemService(ALARM_SERVICE);for(int i=0;i<n;i++){Intent in=new Intent(c,AlarmReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(c,i,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.cancel(pi);pi.cancel();}p.edit().putInt("n",0).apply();}
 static void restore(Context c){SharedPreferences p=c.getSharedPreferences(PREF,0);for(int i=0;i<p.getInt("n",0);i++){String med=p.getString("m"+i,null),time=p.getString("t"+i,null);if(med!=null&&time!=null)set(c,i,med,time);}}
}
